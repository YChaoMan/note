package decorator;

public class Decorator extends Component {
    
//    private Component component;
//    
//    public Decorator(Component component) {
//        this.component = component;
//    }
    protected Component component;
    
    public void encrypt() {
        component.encrypt();
    }

}
