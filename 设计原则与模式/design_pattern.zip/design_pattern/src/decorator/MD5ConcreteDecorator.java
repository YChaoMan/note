package decorator;

public class MD5ConcreteDecorator extends Decorator {

    public MD5ConcreteDecorator(Component component) {
//        super(component);
        super.component = component;
    }
    
    @Override
    public void encrypt() {
        super.encrypt();
        md5Process();
    }
    
    public void encrypts() {
        super.encrypt();
        md5Process();
    }
    
    public void md5Process() {
        System.out.println(">>> MD5 encrypt >>>");
    }
}
