package decorator;

public class RSAConcreteDecorator extends Decorator {

    public RSAConcreteDecorator(Component component) {
//      super(component);
      super.component = component;
    }
    
    @Override
    public void encrypt() {
        super.encrypt();
        rsaProcess();
    }
    
    public void rsaProcess() {
        System.out.println(">>> RSA encrypt >>>");
    }
}
