package decorator;

public class Client {

    public static void main(String[] args) {
        // 透明装饰模式
//        Component component = new Component();
//        Component md5Encrypt = new MD5ConcreteDecorator(component);
//        md5Encrypt.encrypt();
//
//        Component md5AndDesEncrypt = new DESConcreteDecorator(md5Encrypt);
//        md5AndDesEncrypt.encrypt();
//
//        Component md5AndDesAndRsaEncrypt = new RSAConcreteDecorator(md5AndDesEncrypt);
//        md5AndDesAndRsaEncrypt.encrypt();
        
        // 半透明装饰模式
        Component components = new Component();
        MD5ConcreteDecorator md5Encrypts = new MD5ConcreteDecorator(components);
        md5Encrypts.encrypts();

        RSAConcreteDecorator md5AndDesAndRsaEncrypts = new RSAConcreteDecorator(md5Encrypts);
        md5AndDesAndRsaEncrypts.encrypt();
    }

}
