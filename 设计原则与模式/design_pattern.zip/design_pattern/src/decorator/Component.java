package decorator;

public class Component {

    public void encrypt() {
        System.out.println("*** encrypt ***");
    }
}
