package decorator;

public class DESConcreteDecorator extends Decorator {

    public DESConcreteDecorator(Component component) {
//      super(component);
      super.component = component;
    }
    
    @Override
    public void encrypt() {
        super.encrypt();
        desProcess();
    }
    
    public void desProcess() {
        System.out.println(">>> DES encrypt >>>");
    }

}
