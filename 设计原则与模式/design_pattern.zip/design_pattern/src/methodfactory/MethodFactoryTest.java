package methodfactory;

public class MethodFactoryTest {

    public static void main(String[] args) {
//        ProductFactory factoryA = new ProductAFactory();
//        ProductFactory factoryB = new ProductBFactory();
//        System.out.println(factoryA);
//        System.out.println(factoryB);
        
    }
}
