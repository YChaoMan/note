package methodfactory;

public interface Product {

    public void overview();
}
