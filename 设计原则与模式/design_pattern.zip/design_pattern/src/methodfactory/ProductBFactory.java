package methodfactory;

public class ProductBFactory implements ProductFactory {

    @Override
    public Product getProductInstance() {
        // TODO Auto-generated method stub
        return null;
    }

//    @Override
//    public Product getProductInstance() {
//        return new ProductB();
//    }

}
