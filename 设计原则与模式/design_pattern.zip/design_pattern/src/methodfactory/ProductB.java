package methodfactory;

public class ProductB implements Product {
    
    @Override
    public void overview() {
        System.out.println("product b");
    }

}
