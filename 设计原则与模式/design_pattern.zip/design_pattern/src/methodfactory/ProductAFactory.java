package methodfactory;

public class ProductAFactory implements ProductFactory {

    @Override
    public Product getProductInstance() {
        return new ProductA();
    }

}
