package methodfactory;

public interface ProductFactory {

    public Product getProductInstance();
}
