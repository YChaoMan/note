package methodfactory;

public class ProductA implements Product {

    @Override
    public void overview() {
        System.out.println("product a");
    }

}
