package builder;

/**
 * 客户端
 * 
 * @author ycm
 */
public class Client {

    public static void main(String[] args) {
        PlayerModel builder = new FullModel();
        PlayerProduct product = builder.construct();
        System.out.println("完整模式: " + product);
        
        PlayerModel builder2 = new MiniModel();
        PlayerProduct product2 = builder2.construct();
        System.out.println("精简模式: " + product2);
        
        PlayerModel builder3 = new MemoryModel();
        PlayerProduct product3 = builder3.construct();
        System.out.println("记忆模式: " + product3);
    }

}
