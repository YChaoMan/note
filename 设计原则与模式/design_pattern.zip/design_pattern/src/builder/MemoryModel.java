package builder;

/**
 * 具体建造类（ConcreteBuilder），记忆模式
 * 
 * @author ycm
 */
public class MemoryModel extends PlayerModel {

    @Override
    void menu() {
        playerProduct.setMenu((isMenu() ? "菜单" : ""));
    }

    @Override
    void controlBar() {
        playerProduct.setControlBar("控制条");
    }

    @Override
    void collectList() {
        playerProduct.setCollectList("收藏列表");
    }

    @Override
    void mainWindow() {
        playerProduct.setMainWindow("主窗口");
    }
}
