package builder;

/**
 * 具体建造类（ConcreteBuilder），完整模式
 * 
 * @author ycm
 */
public class FullModel extends PlayerModel {

    @Override
    void menu() {
        playerProduct.setMenu("显示菜单");
    }

    @Override
    void controlBar() {
        playerProduct.setControlBar("控制条");
    }

    @Override
    void collectList() {
        playerProduct.setCollectList("收藏列表");
    }

    @Override
    void mainWindow() {
        playerProduct.setMainWindow("主窗口");
    }

}
