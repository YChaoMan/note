package builder;

/**
 * 抽象建造类（Builder）+ 指挥类（Director）
 * 
 * @author ycm
 */
public abstract class PlayerModel {

    protected PlayerProduct playerProduct = new PlayerProduct();

    /**
     * 装配部件
     */
    abstract void menu();

    abstract void controlBar();

    abstract void collectList();

    abstract void mainWindow();

    /**
     * 钩子方法，控制某个部件是否需要进行装配
     */
    protected boolean isMenu() {
        return false;
    }

    protected boolean isControlBar() {
        return false;
    }

    protected boolean isCollectList() {
        return false;
    }

    protected boolean isMainWindow() {
        return false;
    }

    /**
     * 建造产品
     */
    public PlayerProduct construct() {
        this.menu();
        this.controlBar();
        this.collectList();
        this.mainWindow();
        return playerProduct;
    }
}