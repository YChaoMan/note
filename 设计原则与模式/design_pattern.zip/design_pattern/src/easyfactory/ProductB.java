package easyfactory;

public class ProductB extends Product {

    public void overview() {
        System.out.println("product b");
    }
}
