package easyfactory;

public class EasyFactoryTest {
  
    public static void main(String[] args) {
        System.out.println(ProductFactory.getProductInstance("a"));
        System.out.println(ProductFactory.getProductInstance("A"));
        System.out.println(ProductFactory.getProductInstance("b"));
        System.out.println(ProductFactory.getProductInstance("B"));
    }
}
