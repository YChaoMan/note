package easyfactory;

public class ProductFactory {

    public static Product getProductInstance(String productName) {
        if ("a".equalsIgnoreCase(productName)) {
            return new ProductA();
        } else if ("b".equalsIgnoreCase(productName)) {
            return new ProductB();
        } else {
            return null;
        }
    }
}
