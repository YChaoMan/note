package easyfactory;

public abstract class Product {

}
