package easyfactory;

public class ProductA extends Product {
    
    public void overview() {
        System.out.println("product a");
    }
}
