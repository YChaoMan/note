package a;

public class CustomerDAO {

    public void doSomething(Class c) {
        c.shift();
    }
}
