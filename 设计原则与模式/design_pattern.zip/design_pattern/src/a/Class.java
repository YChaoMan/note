package a;

public abstract class Class {

    public abstract void shift();
    
}
