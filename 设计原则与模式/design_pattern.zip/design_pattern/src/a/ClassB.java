package a;

public class ClassB extends Class {

    public void shift() {
        System.out.println(this + " do some thing");
    }
}
