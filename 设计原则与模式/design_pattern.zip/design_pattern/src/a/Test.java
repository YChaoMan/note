package a;

public class Test {

    public static void main(String[] args) {
        CustomerDAO dao = new CustomerDAO();
        dao.doSomething(new ClassB());
        
    }
}
