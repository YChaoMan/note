package a;

//public class ClassA extends Class {
public class ClassA extends A {

    public void shift() {
        System.out.println(this + " do some thing");
    }
}

class A {
    
    public void a() {
        // do something
    }
}

class B extends A {
    
    public void b() {
        super.a();
    }
}
