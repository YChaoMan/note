package adapter;

public class Client {

    public static void main(String[] args) {
        // 对象适配器
        Encrypt encrypt = new Adapter();
        System.out.println(encrypt.encrypt());
        // 缺省适配器
        Encrypt encrypt2 = new Service();
        System.out.println(encrypt2.encrypt());
    }

}
