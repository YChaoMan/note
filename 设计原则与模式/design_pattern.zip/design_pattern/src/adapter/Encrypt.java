package adapter;

public abstract class Encrypt {

     abstract public String encrypt();
}
