package adapter;

public class Adaptee {

    public String md5Encrypt() {
        return "内容经过MD5加密";
    }
}
