package adapter;

public class Adapter extends Encrypt {

    private Adaptee adaptee;
    
    public Adapter() {
        this.adaptee = new Adaptee();
    }
    
    @Override
    public String encrypt() {
        return adaptee.md5Encrypt();
    }

}
