package adapter;

public class DefaultAdapter extends Encrypt {

    @Override
    public String encrypt() {
        return null;
    }

}
