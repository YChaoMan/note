package adapter;

public class Service extends DefaultAdapter {

    @Override
    public String encrypt() {
        
        return "encrypt";
    }
}
