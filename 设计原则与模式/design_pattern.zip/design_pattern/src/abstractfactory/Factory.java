package abstractfactory;

// 电脑外设生产工厂
public interface Factory {

    // 鼠标
    public AbstractProductA createProductA();

    // 键盘
    public AbstractProductB createProductB();
}
