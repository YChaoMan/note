package abstractfactory;

public class AbstractFactoryTest {

    public static void main(String[] args) {
        Factory factory = null;
        // 抽象产品
        AbstractProductA abstractProductA = null;
        AbstractProductB abstractProductB = null;
        
        // 需要一批鼠标，无线的
        factory = new ConcreteFactory1();
        abstractProductA = factory.createProductA();
        // 需要一批鼠标，有线的
        factory = new ConcreteFactory2();
        abstractProductA = factory.createProductA();
        // 需要一批键盘，无线的
        factory = new ConcreteFactory1();
        abstractProductB = factory.createProductB();
        // 需要一批键盘，有线的
        factory = new ConcreteFactory2();
        abstractProductB = factory.createProductB();
    }
}