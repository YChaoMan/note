package abstractfactory;

// 无线鼠标
public class ConcreteProductA1 implements AbstractProductA {

    public ConcreteProductA1() {
        System.out.println("生产无线鼠标");
    }
}
