package abstractfactory;

public interface AbstractProductB {

}
