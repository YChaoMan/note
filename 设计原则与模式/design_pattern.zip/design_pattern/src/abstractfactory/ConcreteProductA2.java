package abstractfactory;

// 有线鼠标
public class ConcreteProductA2 implements AbstractProductA {

    public ConcreteProductA2() {
        System.out.println("生产有线鼠标");
    }
}
