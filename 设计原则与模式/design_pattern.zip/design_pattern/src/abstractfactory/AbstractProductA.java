package abstractfactory;

public interface AbstractProductA {

}
