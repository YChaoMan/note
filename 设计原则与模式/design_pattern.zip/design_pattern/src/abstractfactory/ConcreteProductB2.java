package abstractfactory;

// 有线键盘
public class ConcreteProductB2 implements AbstractProductB {

    public ConcreteProductB2() {
        System.out.println("生产有线键盘");
    }
}
