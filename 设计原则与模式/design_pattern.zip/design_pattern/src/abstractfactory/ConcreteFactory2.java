package abstractfactory;

// 有线生产工厂
public class ConcreteFactory2 implements Factory {

    // 有线鼠标
    @Override
    public AbstractProductA createProductA() {
        return new ConcreteProductA2();
    }

    // 有线键盘
    @Override
    public AbstractProductB createProductB() {
        return new ConcreteProductB2();
    }

}
