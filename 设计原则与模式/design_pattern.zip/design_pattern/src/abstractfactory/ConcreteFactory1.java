package abstractfactory;

// 无线生产工厂
public class ConcreteFactory1 implements Factory {

    // 生产无线鼠标
    @Override
    public AbstractProductA createProductA() {
        return new ConcreteProductA1();
    }

    // 生产无线键盘
    @Override
    public AbstractProductB createProductB() {
        return new ConcreteProductB1();
    }

}
