package abstractfactory;

// 无线键盘
public class ConcreteProductB1 implements AbstractProductB {

    public ConcreteProductB1() {
        System.out.println("生产无线键盘");
    }
}
