package b;

public interface DBUtil {

    public void getConnection();
}
