package b;

public class MySQLConnection implements DBUtil {

    @Override
    public void getConnection() {
        System.out.println("MySQL Connection Finish");        
    }

}
