package b;

public class CustomerDAO  {

    private DBUtil dbConnection;
    
    public CustomerDAO() {
    }
    
    // 构造注入
    public CustomerDAO(DBUtil dbConnection) {
        this.dbConnection = dbConnection;
    }

    // Setter注入
    public void setConnection(DBUtil dbConnection) {
        this.dbConnection = dbConnection;
    }
    
    public void getConnection() {
        dbConnection.getConnection();
    }
}
