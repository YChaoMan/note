package b;

public class OracleConnection implements DBUtil {

    @Override
    public void getConnection() {
        System.out.println("Oracle Connection Finish");
    }

}
