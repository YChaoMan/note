package bridge;

/**
 * 扩充抽象类（RefinedAbstraction）
 * 
 * @author ycm
 */
public class TxtFile extends File {

    @Override
    public void parseFile() {
        System.out.println(dataBase.save() + " 保存txt格式数据");
    }

}
