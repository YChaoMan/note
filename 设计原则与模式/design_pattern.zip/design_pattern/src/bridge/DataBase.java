package bridge;

/**
 * 实现类接口（Implementor）
 * 
 * @author ycm
 */
public interface DataBase {

    public String save();
}
