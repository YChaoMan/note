package bridge;

/**
 * 具体实现类（ConcreteImplementor）
 * 
 * @author ycm
 */
public class SqlServerDataBase implements DataBase {

    @Override
    public String save() {
        return "SqlServer";
    }

}
