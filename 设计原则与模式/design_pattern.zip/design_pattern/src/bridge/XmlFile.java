package bridge;

/**
 * 扩充抽象类（RefinedAbstraction）
 * 
 * @author ycm
 */
public class XmlFile extends File {

    @Override
    public void parseFile() {
        System.out.println(dataBase.save() + " 保存xml格式数据");
    }

}
