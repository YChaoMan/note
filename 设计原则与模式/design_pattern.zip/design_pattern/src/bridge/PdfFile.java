package bridge;

/**
 * 扩充抽象类（RefinedAbstraction）
 * 
 * @author ycm
 */
public class PdfFile extends File {

    @Override
    public void parseFile() {
        System.out.println(dataBase.save() + " 保存pdf格式数据");
    }

}
