package bridge;

interface safa {

}
