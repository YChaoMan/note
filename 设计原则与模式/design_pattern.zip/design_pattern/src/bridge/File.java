package bridge;

/**
 * 抽象类（Abstraction）
 * 
 * @author ycm
 */
public abstract class File {

    protected DataBase dataBase;
    
    public void setDataBase(DataBase dataBase) {
        this.dataBase = dataBase;
    }
    
    public abstract void parseFile();
}
