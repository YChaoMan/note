package bridge;

/**
 * 客户端
 * 
 * @author ycm
 */
public class Client {

    public static void main(String[] args) {
        DataBase dataBase = new MySQLDataBase();
        DataBase dataBase2 = new OracleDataBase();
        
        File parseFile = new TxtFile();
        parseFile.setDataBase(dataBase);
        parseFile.parseFile();
        
        parseFile = new TxtFile();
        parseFile.setDataBase(dataBase2);
        parseFile.parseFile();
        
        parseFile = new PdfFile();
        parseFile.setDataBase(dataBase);
        parseFile.parseFile();
        
        parseFile = new PdfFile();
        parseFile.setDataBase(dataBase2);
        parseFile.parseFile();

    }

}
