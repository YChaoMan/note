package composite;

/**
 * 组合模式之透明组合模式（面向抽象编程，默认）
 * 
 * @author ycm
 */
public class Client {

    public static void main(String[] args) {
        // 透明组合模式，叶子功能
//        InterfaceControl buttonControl = new ButtonControl();
//        buttonControl.show();
//        buttonControl.add(buttonControl);
//        InterfaceControl textControl = new TextControl();
//        textControl.show();
//        textControl.add(textControl);
//        // 容器功能
//        InterfaceControl frameControl = new FrameControl();
//        frameControl.add(buttonControl);
//        frameControl.add(textControl);
//        frameControl.show();
//        InterfaceControl panelControl = new PanelControl();
//        panelControl.add(buttonControl);
//        panelControl.add(textControl);
//        panelControl.show();
        Client2.main(args);
    }

}

/**
 * 组合模式之安全组合模式
 * 
 * @author ycm
 */
class Client2 {
    
    public static void main(String[] args) {
        // 安全组合模式，叶子功能
        InterfaceControl2 buttonControl = new ButtonControl2();
        buttonControl.show();
        InterfaceControl2 textControl = new TextControl2();
        textControl.show();
        // 容器功能
        FrameControl2 frameControl = new FrameControl2();
        frameControl.add(buttonControl);
        frameControl.add(textControl);
        frameControl.show();
        PanelControl2 panelControl = new PanelControl2();
        panelControl.add(buttonControl);
        panelControl.add(textControl);
        panelControl.show();

    }
}
