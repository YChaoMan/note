package composite;

/**
 * 抽象构件（Component）
 * 
 * @author ycm
 */
public abstract class InterfaceControl {

    public abstract void show();
    
    public abstract void add(InterfaceControl interfaceControl);
}

abstract class InterfaceControl2 {
    
    abstract void show();
}
