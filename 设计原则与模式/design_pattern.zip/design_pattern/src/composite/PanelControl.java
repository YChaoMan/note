package composite;

import java.util.ArrayList;
import java.util.List;

/**
 * 容器构件（Composite）
 * 
 * @author ycm
 */
public class PanelControl extends InterfaceControl {

    private List<InterfaceControl> InterfaceControls = new ArrayList<>();
    
    @Override
    public void show() {
        for (InterfaceControl interfaceControl : InterfaceControls) {
            interfaceControl.show();
        }
    }

    @Override
    public void add(InterfaceControl interfaceControl) {
        InterfaceControls.add(interfaceControl);
    }

}

class PanelControl2 extends InterfaceControl2 {
    
    private List<InterfaceControl2> InterfaceControls = new ArrayList<>();
    
    @Override
    public void show() {
        for (InterfaceControl2 interfaceControl : InterfaceControls) {
            interfaceControl.show();
        }
    }
    
    public void add(InterfaceControl2 interfaceControl) {
        InterfaceControls.add(interfaceControl);
    }
    
}
