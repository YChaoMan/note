package composite;

/**
 * 叶子构件（Leaf）
 * 
 * @author ycm
 */
public class TextControl extends InterfaceControl {

    @Override
    public void show() {
        System.out.println("我是：" + this.getClass().getSimpleName());
    }

    @Override
    public void add(InterfaceControl interfaceControl) {
        System.out.println(this.getClass().getSimpleName() + "不支持添加其他控件功能");
    }

}

class TextControl2 extends InterfaceControl2 {

    @Override
    void show() {
        System.out.println("我是：" + this.getClass().getSimpleName());
    }
    
}