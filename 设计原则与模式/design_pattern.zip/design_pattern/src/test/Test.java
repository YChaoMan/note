package test;

import c.ClassFactory;

public class Test {

    public static void main(String[] args) {
//        CustomerDAO dao = new CustomerDAO();
//        dao.setConnection(new OracleConnection());
//        dao.getConnection();
        ClassFactory a = ClassFactory.getClassFactory();
        ClassFactory b = ClassFactory.getClassFactory();
        ClassFactory c = ClassFactory.getClassFactory();
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
    }
    
}
